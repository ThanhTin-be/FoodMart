<?php
require_once __DIR__ . '/../config/database.php';

class DashboardModel {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();;
    }

    public function getDashboardData() {
        $currentDate = '2025-09-27';  // Dựa trên prompt, thay bằng date('Y-m-d') cho thực tế
        $currentMonth = date('Y-m', strtotime($currentDate));
        $currentYear = date('Y', strtotime($currentDate));
        $lastMonth = date('Y-m', strtotime('-1 month', strtotime($currentDate)));
        $lastYear = date('Y', strtotime('-1 year', strtotime($currentDate)));

        // Tổng sản phẩm
        $stmt = $this->db->query("SELECT COUNT(*) as total FROM products");
        $totalProducts = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

        // Tổng khách hàng (users trừ admin)
        $stmt = $this->db->query("SELECT COUNT(*) as total FROM users WHERE role = 'user'");
        $totalCustomers = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

        // Doanh thu tháng (tổng total_price từ orders status 'thanh_cong' trong tháng hiện tại)
        $currentMonth = date('Y-m'); // Lấy tháng hiện tại, ví dụ: 2025-10
        $stmt = $this->db->prepare("SELECT SUM(total_price) as total FROM orders WHERE status = 'thanh_cong' AND DATE_FORMAT(created_at, '%Y-%m') = :month");
        $stmt->execute(['month' => $currentMonth]);
        $monthlyRevenue = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

        // Doanh thu tháng trước (tổng total_price từ orders status 'thanh_cong' trong tháng trước)
        $lastMonth = date('Y-m', strtotime('-1 month', strtotime(date('Y-m-01')))); // Lấy tháng trước, ví dụ: 2025-09
        $stmt = $this->db->prepare("SELECT SUM(total_price) as total FROM orders WHERE status = 'thanh_cong' AND DATE_FORMAT(created_at, '%Y-%m') = :month");
        $stmt->execute(['month' => $lastMonth]);
        $lastMonthlyRevenue = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
        // tính phần trăm tăng giảm
        if ($lastMonthlyRevenue == 0) {
            $monthlyRevenueChange = $monthlyRevenue > 0 ? 100 : 0; // Nếu tháng trước là 0 và tháng này có doanh thu thì tăng 100%
        } else {
            $monthlyRevenueChange = (($monthlyRevenue - $lastMonthlyRevenue) / $lastMonthlyRevenue) * 100;
        }       
        // Đơn hàng hôm nay
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM orders WHERE DATE(created_at) = :date");
        $stmt->execute(['date' => $currentDate]);
        $todayOrders = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

        // Doanh thu năm
        $stmt = $this->db->prepare("SELECT SUM(total_price) as total FROM orders WHERE status = 'thanh_cong' AND DATE_FORMAT(created_at, '%Y') = :year");
        $stmt->execute(['year' => $currentYear]);
        $yearlyRevenue = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

        // Đơn hàng tháng
        $stmt = $this->db->prepare("SELECT COUNT(*) as total FROM orders WHERE DATE_FORMAT(created_at, '%Y-%m') = :month");
        $stmt->execute(['month' => $currentMonth]);
        $monthlyOrders = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

        // Giá trị đơn TB tháng
        $avgOrderValue = ($monthlyOrders > 0) ? $monthlyRevenue / $monthlyOrders : 0;

        // Tỷ lệ chuyển đổi (giả sử 3.2% như dữ liệu mẫu, bạn có thể tính dựa trên views/orders nếu có dữ liệu)
        $conversionRate = 3.2;  // Có thể query nếu có bảng views

        // Revenue Data (tháng: 12 tháng gần nhất, quý: 5 quý, năm: 5 năm)
        $revenueData = [
            'month' => $this->getRevenueByMonth(),
            'quarter' => $this->getRevenueByQuarter(),
            'year' => $this->getRevenueByYear()
        ];

        // Sales Performance (ví dụ: 4 tuần gần nhất)
        $salesPerformance = $this->getSalesPerformance();

        // Top Products (dựa trên quantity từ order_items, top 5)
        $topProducts = $this->getTopProducts();

        // Top Categories (dựa trên revenue từ products/categories)
        $topCategories = $this->getTopCategories();

        // Recent Orders (5 đơn hàng gần nhất)
        $recentOrders = $this->getRecentOrders();

        // Products List (tất cả products, hoặc paginate)
        $products = $this->getProducts();

        // Customers List
        $customers = $this->getCustomers();

        // Categories
        $categories = $this->getCategories();

        return [
            'stats' => [
                'totalProducts' => $totalProducts,
                'totalCustomers' => $totalCustomers,
                'monthlyRevenue' => $monthlyRevenue,
                'lastMonthlyRevenue' => $lastMonthlyRevenue,
                'monthlyRevenueChange' => $monthlyRevenueChange,
                'todayOrders' => $todayOrders,
                'yearlyRevenue' => $yearlyRevenue,
                'monthlyOrders' => $monthlyOrders,
                'avgOrderValue' => $avgOrderValue,
                'conversionRate' => $conversionRate
            ],
            'revenueData' => $revenueData,
            'salesPerformance' => $salesPerformance,
            'topProducts' => $topProducts,
            'topCategories' => $topCategories,
            'recentOrders' => $recentOrders,
            'products' => $products,
            'customers' => $customers,
            'categories' => $categories
        ];
    }

    private function getRevenueByMonth() {
        // Query doanh thu 12 tháng gần nhất (triệu VNĐ)
        $stmt = $this->db->query("SELECT DATE_FORMAT(created_at, '%Y-%m') as label, SUM(total_price)/1000000 as data 
                                  FROM orders WHERE status = 'thanh_cong' 
                                  GROUP BY label ORDER BY label DESC ");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return [
            'labels' => array_column($data, 'label'),
            'data' => array_column($data, 'data')
        ];
    }

    private function getRevenueByQuarter(){
    // Query doanh thu theo quý (triệu VNĐ) từ database
    $stmt = $this->db->query("
        SELECT 
            CONCAT('Q', QUARTER(created_at), ' ', YEAR(created_at)) as label,
            SUM(total_price) / 1000000 as data
        FROM orders
        WHERE status = 'thanh_cong'
        GROUP BY YEAR(created_at), QUARTER(created_at)
        ORDER BY YEAR(created_at) DESC, QUARTER(created_at) DESC
    ");
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Nếu không có dữ liệu, trả về 4 quý của năm hiện tại với giá trị 0
    if (empty($data)) {
        $currentYear = date('Y'); // 2025
        $labels = ['Q1 ' . $currentYear, 'Q2 ' . $currentYear, 'Q3 ' . $currentYear, 'Q4 ' . $currentYear];
        $data = array_fill(0, 4, 0);
        return [
            'labels' => $labels,
            'data' => $data
        ];
    }

    // Trả về mảng labels và data
    return [
        'labels' => array_column($data, 'label'),
        'data' => array_column($data, 'data')
    ];
  }

    private function getRevenueByYear() {
        // Doanh thu 5 năm (tỷ VNĐ)
        $stmt = $this->db->query("SELECT DATE_FORMAT(created_at, '%Y') as label, SUM(total_price)/1000000000 as data 
                                  FROM orders WHERE status = 'thanh_cong' 
                                  GROUP BY label ORDER BY label DESC LIMIT 5");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return [
            'labels' => array_column($data, 'label'),
            'data' => array_column($data, 'data')
        ];
    }

    private function getSalesPerformance() {
        // Ví dụ: Doanh số 4 tuần (tính từ DB)
        return [
            'labels' => ['Tuần 1', 'Tuần 2', 'Tuần 3', 'Tuần 4'],
            'datasets' => [
                ['label' => 'Doanh số', 'data' => [28, 32, 35, 30], 'backgroundColor' => '#4F46E5'],
                ['label' => 'Mục tiêu', 'data' => [30, 30, 30, 30], 'backgroundColor' => '#E5E7EB']
            ]
        ];
    }

    private function getTopProducts() {
        $stmt = $this->db->query("SELECT p.name as label, SUM(oi.quantity) as data 
                                  FROM order_items oi JOIN products p ON oi.product_id = p.id 
                                  GROUP BY p.id ORDER BY data DESC LIMIT 5");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
        return [
            'labels' => array_column($data, 'label'),
            'data' => array_column($data, 'data')
        ];
    }

    private function getTopCategories() {
        $stmt = $this->db->query("SELECT c.name, SUM(oi.quantity * oi.price) as revenue, COUNT(p.id) as products 
                                  FROM categories c JOIN products p ON c.id = p.category_id 
                                  JOIN order_items oi ON p.id = oi.product_id 
                                  GROUP BY c.id ORDER BY revenue DESC LIMIT 6");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function getRecentOrders() {
        $stmt = $this->db->query("SELECT o.id, u.name as customer, o.total_price as total, o.status 
                                  FROM orders o JOIN users u ON o.user_id = u.id 
                                  ORDER BY o.created_at DESC LIMIT 6");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function getProducts() {
        $stmt = $this->db->query("SELECT * FROM products ");  // Paginate nếu cần
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function getCustomers() {
        $stmt = $this->db->query("SELECT * FROM users WHERE role = 'user' LIMIT 10");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    private function getCategories() {
        $stmt = $this->db->query("SELECT * FROM categories");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}