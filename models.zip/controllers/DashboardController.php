<?php
require_once __DIR__ . '/../models/DashboardModel.php';

class DashboardController {
    public function index() {
        $model = new DashboardModel();
        $dashboardData = $model->getDashboardData();

        // Truyền dữ liệu đến view
        require_once __DIR__ . '/../views/admin/dashboard.php';
    }
}
?>