<?php   
    class CartController extends Controller {
        public function index() {
            $this->view("cart/index");
        }
    }
?>