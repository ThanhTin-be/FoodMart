<?php
class CartController extends Controller {

    // Trang giỏ hàng
    public function index() {
        $cart = $_SESSION['cart'] ?? [];
        $total = $this->getCartTotal();
        $this->view("cart/index", [
            'cart' => $cart,
            'total' => $total
        ]);
    }

    // Thêm sản phẩm vào giỏ (AJAX)
    public function add($id = null) {
        if ($id === null) {
            $id = $_GET['id'] ?? null;
        }

        if (!$id) {
            header("HTTP/1.1 400 Bad Request");
            echo json_encode(['success' => false, 'message' => 'Thiếu ID sản phẩm']);
            exit;
        }

        $id = intval($id);
        $productModel = $this->model("ProductModel");
        $product = $productModel->getById($id);

        if (!$product) {
            header("HTTP/1.1 404 Not Found");
            echo json_encode(['success' => false, 'message' => 'Không tìm thấy sản phẩm']);
            exit;
        }

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // ✅ Nếu sản phẩm đã có → tăng số lượng
        if (isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['qty'] += 1;
        } else {
            $_SESSION['cart'][$id] = [
                'id'    => $product['id'],
                'name'  => $product['name'],
                'price' => (float)$product['price'],
                'qty'   => 1,
                'image' => $product['image']
            ];
        }

        // ✅ Tính tổng giỏ hàng
        $total = 0;
        $count = 0;
        foreach ($_SESSION['cart'] as $item) {
            $total += $item['price'] * $item['qty'];
            $count += $item['qty'];
        }

        // ✅ Nếu là AJAX thì trả JSON
       // CartController.php
        if (isset($_GET['ajax'])) {
            header('Content-Type: application/json');
            echo json_encode([
                'success' => true,
                'count'   => count($_SESSION['cart']),
                'total'   => $this->getCartTotal(),
                'cart'    => array_values($_SESSION['cart']) // gửi toàn bộ giỏ hàng
            ]);
            exit;
        }
        header("Location: " . $_SERVER['HTTP_REFERER']);
    }

    // Xóa sản phẩm
    public function remove($id = null) {
        if ($id && isset($_SESSION['cart'][$id])) {
            unset($_SESSION['cart'][$id]);
        }
        header("Location: " . $_SERVER['HTTP_REFERER']);
    }

    // Helper tính tổng tiền
    private function getCartTotal() {
        $total = 0;
        if (!empty($_SESSION['cart'])) {
            foreach ($_SESSION['cart'] as $item) {
                $total += $item['price'] * $item['qty'];
            }
        }
        return $total;
    }
}
